import javafx.animation.PathTransition;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;

public class Main extends Application {

    @Override
    public void start(Stage stage) {
        Pane pane = new Pane();

        Line line = new Line(1,1,50,50);
        line.setStroke(Color.BLACK);
        Line line2 = new Line(50,50,200,100);
        line2.setStroke(Color.BLACK);
        ArrayList<Line> lineList = new ArrayList<>();
        Circle circle = new Circle(25);
        circle.setFill(Color.BLUE);

        Shape linesAdded = new Shape() {
            @Override
            public com.sun.javafx.geom.Shape impl_configShape() {
                return null;
            }
        };pane.getChildren().addAll(line,line2,circle);

        PathTransition ptNextStep = new PathTransition();
        ptNextStep.setDuration(Duration.millis(200));
        ptNextStep.setNode(circle);
        ptNextStep.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
        ptNextStep.setCycleCount(1);
        ptNextStep.play();
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
