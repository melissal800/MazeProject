import javafx.geometry.Point2D;
import jdk.nashorn.internal.runtime.arrays.ArrayIndex;

import java.awt.*;
import java.util.ArrayList;

public class Maze {

    private int[][] maze;
    private int currentRow = 0; // Entry point row.  Used in takeStep()
    private int currentCol = 2; // Entry point column. Used in takeStep()
    private char lastStep = 'D'; // Sets starting direction for takeStep()

    public Maze(int[][] inputMaze) {
        this.maze = inputMaze;
    }

    /*
    The displayMaze() loops through each row of maze[][]
    If value in maze[][] = 1, " " will be printed to console
    If value in maze[][] = 0, "#" will be printed to console
     */
    public void display() {
        int numOfCol = maze[0].length, numOfRow = maze.length;

        for (int countRow = 0; countRow < numOfRow; countRow++) {
            for (int countCol = 0; countCol < numOfCol; countCol++) {
                if (maze[countRow][countCol] == 1) {
                    System.out.print(" ");
                } else {
                    System.out.print("#");
                }
            }
            System.out.print("\n");
        }
    }

    public String[][] maze() {
        /*
        // Were you planning on using this method for something?
        It looks like it displays the maze, but the displayMaze() method will do that too
         */
        int numOfCol = maze[0].length, numOfRow = maze.length;
        String[][] mazeToDisplay = new String[numOfRow][numOfCol];

        for (int countRow = 0; countRow < numOfRow; countRow++) {
            for (int countCol = 0; countCol < numOfCol; countCol++) {
                if (maze[countRow][countCol] == 1) {
                    mazeToDisplay[countRow][countCol] = " ";
                } else {
                    mazeToDisplay[countRow][countCol] = "#";
                }
            }
        }
        return mazeToDisplay;
    }

    /*
    The getWidth() and getHeight() methods will be used for window sizing purposes in the GUI
     */
    public int getWidth() {
        return maze[0].length;
    }

    public int getHeight() {
        return maze.length;
    }

    // Used to retrieve values from the maze
    public int get(int row, int col) {
        return maze[row][col];
    }

    /*
    The takeStep() method uses if statements to check for the next step
    Checks column to the right (right) and returns char r if true
    Checks lower row (down) and returns d if true
    Checks column to the left (left) and returns l if true
    Checks row above (up) and returns u if true
     */
    public Point2D takeStep() {
        Point2D nextStep;
        switch (lastStep) {
            case 'R':
                if (maze[currentRow + 1][currentCol] == 1) {
                    currentRow++;
                    lastStep = 'D';
                    return new Point2D(currentCol, currentRow);
                } else if (maze[currentRow][currentCol + 1] == 1) {
                    currentCol++;
                    lastStep = 'R';
                    return new Point2D(currentCol, currentRow);
                } else if (maze[currentRow - 1][currentCol] == 1) {
                    currentRow--;
                    lastStep = 'U';
                    return new Point2D(currentCol, currentRow);
                } else {
                    lastStep = 'L';
                    currentCol--;
                    return new Point2D(currentCol, currentRow);
                }
            case 'U':
                if (maze[currentRow][currentCol + 1] == 1) {
                    currentCol++;
                    lastStep = 'R';
                    return new Point2D(currentCol, currentRow);
                } else if (maze[currentRow - 1][currentCol] == 1) {
                    currentRow--;
                    lastStep = 'U';
                    return new Point2D(currentCol, currentRow);
                } else if (maze[currentRow][currentCol - 1] == 1) {
                    lastStep = 'L';
                    currentCol--;
                    return new Point2D(currentCol, currentRow);
                } else {
                    currentRow++;
                    lastStep = 'D';
                    return new Point2D(currentCol, currentRow);

                }
            case 'D':
                if (maze[currentRow][currentCol - 1] == 1) {
                    lastStep = 'L';
                    currentCol--;
                    return new Point2D(currentCol, currentRow);
                } else if (maze[currentRow + 1][currentCol] == 1) {
                    currentRow++;
                    lastStep = 'D';
                    return new Point2D(currentCol, currentRow);
                } else if (maze[currentRow][currentCol + 1] == 1) {
                    currentCol++;
                    lastStep = 'R';
                    return new Point2D(currentCol, currentRow);
                } else {
                    currentRow--;
                    lastStep = 'U';
                    return new Point2D(currentCol, currentRow);
                }
            case 'L':
                if (maze[currentRow - 1][currentCol] == 1) {
                    currentRow--;
                    lastStep = 'U';
                    return new Point2D(currentCol, currentRow);
                } else if (maze[currentRow][currentCol - 1] == 1) {
                    lastStep = 'L';
                    currentCol--;
                    return new Point2D(currentCol, currentRow);
                } else if (maze[currentRow + 1][currentCol] == 1) {
                    currentRow++;
                    lastStep = 'D';
                    return new Point2D(currentCol, currentRow);
                } else {
                    currentCol++;
                    lastStep = 'R';
                    return new Point2D(currentCol, currentRow);
                }
        }
        return new Point2D(0, 0);
    }
    public ArrayList<Point2D> findExit() {
        ArrayList<Point2D> pointList = new ArrayList<>();
        do {
            pointList.add(takeStep());
        } while (currentRow != 0 && currentRow != getHeight() - 1 && currentCol != 0 && currentCol != getWidth() - 1);
        return pointList;
    }
}

