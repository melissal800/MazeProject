import javafx.animation.Animation;
import javafx.animation.PathTransition;
import javafx.animation.SequentialTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.util.ArrayList;

public class SolveTheMaze extends Application{

    int[][] mazeArray = {
            {0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0},
            {0,0,1,0,0,0,0,0,0,0,1,1,1,1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0},
            {0,0,1,1,1,1,1,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,1,1,1,1,0},
            {0,0,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0},
            {0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0},
            {0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
    };

    // Creates a maze object
    Maze maze = new Maze(mazeArray);

    Stage startupStage = new Stage();

    // Creates all panes
    GridPane mazeGrid = new GridPane();
    BorderPane startPane = new BorderPane();
    VBox selectUnicornPane = new VBox(25);
    BorderPane mazePane = new BorderPane();
    HBox selectUnicornImageBox = new HBox(20);
    StackPane tempMazeStack = new StackPane();
    Pane animationPane = new Pane();
    HBox topMazeBox = new HBox(40);

    // Adds images of all unicorns
    Image unicornImage = new Image("images/unicorn.png");
    ImageView unicorn = new ImageView(unicornImage);
    Image unicornImage2 = new Image("images/unicorn2.gif");
    ImageView unicorn2 = new ImageView(unicornImage2);
    Image unicornImage3 = new Image("images/unicorn3.gif");
    ImageView unicorn3 = new ImageView(unicornImage3);
    Image bgMagical = new Image("images/background.jpg");
    ImageView selectedUnicorn;
    Image icon = new Image("images/icon.png");

    // ArrayLists used for taking steps
    Point2D ptNewPos;
    Point2D ptCurPos = new Point2D(2,0);

    // Buttons located in mazePane
    Button btTakeStep = new Button("Take Step");
    Button btFindExit = new Button("Find Exit");

    String unicornName = "";

    @Override
    public void start(Stage startupStage) {
        launchScreen();
    }
    public void launchScreen() {
        // Sets the background for the starting pane
        Image bgUnicorn = new Image("images/startupBackground.jpg");
        Background startupBackground = new Background(new BackgroundImage(bgUnicorn, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, new BackgroundSize(BackgroundSize.AUTO,
                BackgroundSize.AUTO, false, false, true, false)));
        startPane.setBackground(startupBackground);

        // Prompts user to enter a name for the unicorn and select which unicorn they want to use
        Text txtEnterUnicornName = new Text("Enter Your Unicorns Name");
        txtEnterUnicornName.setStyle("-fx-fill: midnightblue; -fx-font-weight: bold; -fx-font-size: 40");

        TextField tfUnicornName = new TextField();
        tfUnicornName.setMaxWidth(400);
        tfUnicornName.setAlignment(Pos.TOP_RIGHT);
        tfUnicornName.setStyle("-fx-text-inner-color: mediumpurple; -fx-background-color: lightgoldenrodyellow;" +
                "-fx-font-weight: bold; -fx-font-size: 35;");

        Text txtSelectUnicorn = new Text("Select Your Unicorn");
        txtSelectUnicorn.setStyle("-fx-fill: midnightblue; -fx-font-weight: bold; -fx-font-size: 40");

        // Sets size of unicorn images in startup pane
        unicorn.setFitHeight(100);
        unicorn.setFitWidth(100);
        unicorn2.setFitHeight(100);
        unicorn2.setFitWidth(100);
        unicorn3.setFitHeight(100);
        unicorn3.setFitWidth(100);

        // Puts each unicorn image into a button and sets style
        Button btUnicornOne = new Button();
        btUnicornOne.setGraphic(unicorn);
        btUnicornOne.setStyle("-fx-background-color: dodgerblue; -fx-text-fill: white;");
        Button btUnicornTwo = new Button();
        btUnicornTwo.setGraphic(unicorn2);
        btUnicornTwo.setStyle("-fx-background-color: dodgerblue; -fx-text-fill: white;");
        Button btUnicornThree = new Button();
        btUnicornThree.setGraphic(unicorn3);
        btUnicornThree.setStyle("-fx-background-color: dodgerblue; -fx-text-fill: white;");

        // Adds unicorn images to Hbox
        selectUnicornImageBox.getChildren().addAll(btUnicornOne, btUnicornTwo, btUnicornThree);
        selectUnicornImageBox.setAlignment(Pos.CENTER_RIGHT);

        // Adds text, text box, and unicorn hbox to pane
        selectUnicornPane.getChildren().addAll(txtEnterUnicornName,tfUnicornName,txtSelectUnicorn,selectUnicornImageBox);

        // Sets padding on right side of vbox to move it more towards the center
        selectUnicornPane.setAlignment(Pos.CENTER_RIGHT);
        selectUnicornPane.setPadding(new Insets(0,75,0,0));

        // Sets the startup pane
        startPane.setCenter(selectUnicornPane);

        // Event handlers that invoke the setmaze method
        btUnicornOne.setOnMouseClicked(event -> {
            selectedUnicorn = new ImageView(unicornImage);
            unicornName = tfUnicornName.getText();
            setMaze();
            startupStage.close();
        });
        btUnicornTwo.setOnMouseClicked(event -> {
            selectedUnicorn = new ImageView(unicornImage2);
            unicornName = tfUnicornName.getText();
            setMaze();
            startupStage.close();
        });
        btUnicornThree.setOnMouseClicked(event -> {
            selectedUnicorn = new ImageView(unicornImage3);
            unicornName = tfUnicornName.getText();
            setMaze();
            startupStage.close();
        });

        // Sets the scene and sets the size of the scene to the window width that is calculated in the maze class
        Scene launchScene = new Scene(startPane,(bgUnicorn.getWidth() / 2) - 5, (bgUnicorn.getHeight() / 2) - 5);
        startupStage.getIcons().add(icon);
        startupStage.setScene(launchScene);
        startupStage.setTitle("Unicorn Maze - Select Your Unicorn");
        startupStage.setResizable(false);
        startupStage.show();
    }
    public void setMaze() {
        // Creates new window for maze
        Stage mazeStage = new Stage();

        // Sets background for mazePane
        topMazeBox.setAlignment(Pos.TOP_CENTER);
        topMazeBox.setPadding(new Insets(25));
        Image bgUnicorn = new Image("images/side_background.jpg");
        Background leftPaneBackground = new Background(new BackgroundImage(bgUnicorn, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, new BackgroundSize(BackgroundSize.AUTO,
                BackgroundSize.AUTO, false, false, true, true)));
        topMazeBox.setBackground(leftPaneBackground);

        /*
        Loops through the array one row at a time
        If a 0 is found, a black square is created
        If a 1 is found, a white square is created
        The square is then added to the grid pane with the xCord and yCord = maze[x][y]
        */

        for (int hGrid = 0; hGrid < maze.getHeight(); hGrid++) {
            for (int vGrid = 0; vGrid < maze.getWidth(); vGrid++) {
                if (maze.get(hGrid,vGrid) == 0) {
                    Rectangle filledBlock = new Rectangle(30,30);
                    filledBlock.setFill(Color.DARKBLUE);
                    filledBlock.setOpacity(.7);
                    GridPane.setConstraints(filledBlock, vGrid, hGrid);
                    mazeGrid.getChildren().add(filledBlock);
                } else {
                    Rectangle filledBlock = new Rectangle(30,30);
                    filledBlock.setFill(Color.PURPLE);
                    filledBlock.setOpacity(.7);
                    GridPane.setConstraints(filledBlock, vGrid, hGrid);
                    mazeGrid.getChildren().add(filledBlock);
                }
            }
        }

        // Button to take next step and find exit
        btTakeStep.setDefaultButton(false);
        btTakeStep.setOnAction(event -> {
            animateNextStep();
        });
        btFindExit.setDefaultButton(false);
        btFindExit.setOnAction(event -> {
            btFindExit.setDisable(true);
            btTakeStep.setDisable(true);
            animateFindExit();
        });
        Button btExit = new Button("Quit");
        btExit.setDefaultButton(false);
        btExit.setOnAction(event -> {
            mazeStage.close();
        });

        topMazeBox.getChildren().addAll(btTakeStep,btFindExit,btExit);

        // Sets the size of the unicorn image for the maze
        selectedUnicorn.setX(60);
        selectedUnicorn.setFitHeight(20);
        selectedUnicorn.setFitWidth(20);
        animationPane.getChildren().add(selectedUnicorn);

        tempMazeStack.getChildren().addAll(mazeGrid,animationPane);
        mazePane.setCenter(tempMazeStack);
        mazePane.setTop(topMazeBox);

        // Sets background for the mazePane
        Background background = new Background(new BackgroundImage(bgMagical, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT));
        mazePane.setBackground(background);

        Scene mazeScene = new Scene(mazePane);
        mazeStage.setScene(mazeScene);
        mazeStage.getIcons().add(icon);
        mazeStage.setTitle("Unicorn Maze:");
        mazeStage.setResizable(false);
        mazeStage.show();
    }

    public void animateNextStep() {
        try {
            ptNewPos = maze.takeStep();

            Line lnNextStep = new Line((ptCurPos.getX() * 30) + 15,(ptCurPos.getY() * 30) + 15,
                    ptNewPos.getX() * 30 + 15,(ptNewPos.getY() * 30) + 15);
            lnNextStep.setStroke(Color.TRANSPARENT);
            animationPane.getChildren().addAll(lnNextStep);

            PathTransition ptNextStep = new PathTransition();
            ptNextStep.setDuration(Duration.millis(200));
            ptNextStep.setNode(selectedUnicorn);
            ptNextStep.setPath(lnNextStep);
            ptNextStep.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
            ptNextStep.play();

            ptCurPos = new Point2D(ptNewPos.getX(), ptNewPos.getY());
        } catch (ArrayIndexOutOfBoundsException e) {
            btTakeStep.setDisable(true);
            btFindExit.setDisable(true);
            mazeComplete();
        }
    }

    public void animateFindExit() {
        // All points for path
        ArrayList<Point2D> pointList = maze.findExit();
        // Used to add all paths into one
        SequentialTransition stFullPath = new SequentialTransition();

        // Creates lines for each point2d and adds pathTransition for each line
        for (int i = 0; i < pointList.size(); i++) {
            ptNewPos = pointList.get(i);

            Line lnFindExit = new Line((ptCurPos.getX() * 30) + 15,(ptCurPos.getY() * 30) + 15,
                    ptNewPos.getX() * 30 + 15,(ptNewPos.getY() * 30) + 15);
            lnFindExit.setStroke(Color.TRANSPARENT);
            animationPane.getChildren().addAll(lnFindExit);

            PathTransition ptFindExit = new PathTransition();
            ptFindExit.setDuration(Duration.millis(200));
            ptFindExit.setNode(selectedUnicorn);
            ptFindExit.setPath(lnFindExit);
            ptFindExit.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);

            ptCurPos = new Point2D(ptNewPos.getX(), ptNewPos.getY());

            stFullPath.getChildren().add(ptFindExit);
        }
        stFullPath.play();

    }

    public void mazeComplete() {
        Stage endGameStage = new Stage();
        VBox vbEndGame = new VBox(20);
        BorderPane bpEndGame = new BorderPane();
        bpEndGame.setPadding(new Insets(20));

        // Background
        Image bgUnicorn = new Image("images/startupBackground.jpg");
        Background startupBackground = new Background(new BackgroundImage(bgUnicorn, BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, new BackgroundSize(BackgroundSize.AUTO,
                BackgroundSize.AUTO, false, false, true, false)));
        bpEndGame.setBackground(startupBackground);

        // Text
        Text txtCongratulations = new Text("Congratulations!");
        txtCongratulations.setStyle("-fx-fill: midnightblue; -fx-font-weight: bold; -fx-font-size: 40");
        Text txtUnicornFinished = new Text( unicornName + " has found the exit");
        txtUnicornFinished.setStyle("-fx-fill: midnightblue; -fx-font-weight: bold; -fx-font-size: 30");
        vbEndGame.getChildren().addAll(txtCongratulations,txtUnicornFinished);
        vbEndGame.setAlignment(Pos.CENTER);

        bpEndGame.setRight(vbEndGame);

        Scene endScene = new Scene(bpEndGame,(bgUnicorn.getWidth() / 2) - 5,(bgUnicorn.getHeight() / 2) - 5);
        endGameStage.setScene(endScene);
        endGameStage.setTitle("Congratulations");
        endGameStage.setResizable(false);
        endGameStage.getIcons().add(icon);
        endGameStage.show();
    }
}